Metadata Link: https://www.fisheries.noaa.gov/inport/q?keywords=FL3502
